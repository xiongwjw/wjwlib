﻿namespace Bing.Datas.EntityFramework.PgSql
{
    /// <summary>
    /// 映射
    /// </summary>
    public interface IMap : Bing.Datas.EntityFramework.Core.IMap
    {
    }
}
