﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Jd.Configs
{
    /// <summary>
    /// 京东授权配置
    /// </summary>
    public class JdAuthorizationConfig : AuthorizationConfigBase
    {
    }
}
