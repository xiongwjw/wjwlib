﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Alibaba.Configs
{
    /// <summary>
    /// 阿里巴巴授权配置
    /// </summary>
    public class AlibabaAuthorizationConfig : AuthorizationConfigBase
    {
    }
}
