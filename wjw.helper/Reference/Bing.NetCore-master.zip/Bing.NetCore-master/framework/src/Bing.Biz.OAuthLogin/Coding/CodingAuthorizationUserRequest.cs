﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Coding
{
    /// <summary>
    /// Coding.NET 授权用户请求
    /// </summary>
    public class CodingAuthorizationUserRequest : AuthorizationUserParamBase
    {
    }
}
