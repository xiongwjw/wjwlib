﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Facebook.Configs
{
    /// <summary>
    /// Facebook 授权配置
    /// </summary>
    public class FacebookAuthorizationConfig : AuthorizationConfigBase
    {
    }
}
