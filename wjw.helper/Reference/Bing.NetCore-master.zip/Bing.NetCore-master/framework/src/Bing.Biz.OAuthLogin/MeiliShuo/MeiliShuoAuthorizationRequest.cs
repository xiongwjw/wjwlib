﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.MeiliShuo
{
    /// <summary>
    /// 美丽说授权请求
    /// </summary>
    public class MeiliShuoAuthorizationRequest : AuthorizationParamBase
    {
    }
}
