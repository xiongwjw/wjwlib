﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Youzan.Configs
{
    /// <summary>
    /// 有赞授权配置
    /// </summary>
    public class YouzanAuthorizationConfig : AuthorizationConfigBase
    {
    }
}
