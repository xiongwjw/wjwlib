﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Gitee
{
    /// <summary>
    /// Gitee 授权请求
    /// </summary>
    public class GiteeAuthorizationRequest : AuthorizationParamBase
    {
    }
}
