﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.QQ
{
    /// <summary>
    /// QQ 授权请求
    /// </summary>
    public class QQAuthorizationRequest : AuthorizationParamBase
    {
    }
}
