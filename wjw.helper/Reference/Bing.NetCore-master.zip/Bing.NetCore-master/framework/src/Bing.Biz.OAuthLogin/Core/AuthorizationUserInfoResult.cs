﻿namespace Bing.Biz.OAuthLogin.Core
{
    /// <summary>
    /// 用户信息结果
    /// </summary>
    public class AuthorizationUserInfoResult
    {
    }
}
