﻿namespace Bing.Biz.OAuthLogin.Core
{
    /// <summary>
    /// 授权用户参数
    /// </summary>
    public class AuthorizationUserParam : AuthorizationUserParamBase
    {
    }
}
