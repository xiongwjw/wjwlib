﻿namespace Bing.Biz.OAuthLogin
{
    /// <summary>
    /// OAuth 登录工厂
    /// </summary>
    public interface IOAuthLoginFactory
    {
    }
}
