﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.DingTalk.Configs
{
    /// <summary>
    /// 钉钉授权配置
    /// </summary>
    public class DingTalkAuthorizationConfig : AuthorizationConfigBase
    {
    }
}
