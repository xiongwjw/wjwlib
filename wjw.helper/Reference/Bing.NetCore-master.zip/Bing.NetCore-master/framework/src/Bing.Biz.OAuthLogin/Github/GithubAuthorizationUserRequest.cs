﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.Github
{
    /// <summary>
    /// Github 授权用户请求
    /// </summary>
    public class GithubAuthorizationUserRequest : AuthorizationUserParamBase
    {
    }
}
