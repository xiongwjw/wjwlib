﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.OsChina.Configs
{
    /// <summary>
    /// 开源中国授权配置
    /// </summary>
    public class OsChinaAuthorizationConfig : AuthorizationConfigBase
    {
    }
}
