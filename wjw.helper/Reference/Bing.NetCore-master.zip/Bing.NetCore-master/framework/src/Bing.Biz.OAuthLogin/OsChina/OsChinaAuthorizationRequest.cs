﻿using Bing.Biz.OAuthLogin.Core;

namespace Bing.Biz.OAuthLogin.OsChina
{
    /// <summary>
    /// 开源中国授权请求
    /// </summary>
    public class OsChinaAuthorizationRequest : AuthorizationParamBase
    {
    }
}
