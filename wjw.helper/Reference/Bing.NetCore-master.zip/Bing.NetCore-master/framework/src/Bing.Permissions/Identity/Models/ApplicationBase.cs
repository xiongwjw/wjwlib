﻿namespace Bing.Permissions.Identity.Models
{
    /// <summary>
    /// 应用程序基类
    /// </summary>
    public abstract partial class ApplicationBase<TApplication, TKey>
    {
    }
}
