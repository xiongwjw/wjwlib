﻿namespace Bing.Biz.Payments.Alipay.Parameters.Requests
{
    /// <summary>
    /// 支付宝App支付参数
    /// </summary>
    public class AlipayAppPayRequest : AlipayRequestBase
    {
    }
}
