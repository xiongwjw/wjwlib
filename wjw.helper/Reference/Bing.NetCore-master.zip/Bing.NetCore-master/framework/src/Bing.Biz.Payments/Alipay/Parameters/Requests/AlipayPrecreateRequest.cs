﻿namespace Bing.Biz.Payments.Alipay.Parameters.Requests
{
    /// <summary>
    /// 支付宝预创建支付参数
    /// </summary>
    public class AlipayPrecreateRequest : AlipayRequestBase
    {
    }
}
