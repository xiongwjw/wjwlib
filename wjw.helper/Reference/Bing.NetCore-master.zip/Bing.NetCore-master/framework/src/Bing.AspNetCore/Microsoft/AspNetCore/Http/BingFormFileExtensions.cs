﻿namespace Microsoft.AspNetCore.Http
{
    /// <summary>
    /// 表单文件(<see cref="IFormFile"/>) 扩展
    /// </summary>
    public static class BingFormFileExtensions
    {
    }
}
