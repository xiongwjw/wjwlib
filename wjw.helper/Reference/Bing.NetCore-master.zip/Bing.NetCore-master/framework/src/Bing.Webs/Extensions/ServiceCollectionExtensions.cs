﻿using Microsoft.Extensions.DependencyInjection;

namespace Bing.Webs.Extensions
{
    /// <summary>
    /// 服务集合(<see cref="IServiceCollection"/>) 扩展
    /// </summary>
    public static class ServiceCollectionExtensions
    {
    }
}
