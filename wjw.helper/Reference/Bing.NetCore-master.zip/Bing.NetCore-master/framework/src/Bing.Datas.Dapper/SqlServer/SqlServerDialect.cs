﻿using Bing.Datas.Sql.Builders.Core;

namespace Bing.Datas.Dapper.SqlServer
{
    /// <summary>
    /// Sql Server方言
    /// </summary>
    public class SqlServerDialect : DialectBase
    {
    }
}
