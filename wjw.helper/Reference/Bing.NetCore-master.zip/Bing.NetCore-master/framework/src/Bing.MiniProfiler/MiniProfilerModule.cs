﻿using System.ComponentModel;

namespace Bing.MiniProfiler
{
    /// <summary>
    /// MiniProfiler 模块
    /// </summary>
    [Description("MiniProfiler模块")]
    public class MiniProfilerModule : MiniProfilerModuleBase
    {
    }
}
